package com.example.pythonarabic

import android.app.*
import android.os.Bundle
import android.widget.*
import android.text.*
import android.content.*
import android.graphics.Color

data class Item(val category:String,val name:String,val meaning:String,val benefit:String,val example:String)

class MainActivity : Activity() {
    private val items = listOf(
        Item("الدوال المدمجة","print()","طباعة البيانات","عرض النصوص والنتائج على الشاشة","print('مرحبا')"),
        Item("الدوال المدمجة","input()","إدخال البيانات","قراءة قيمة من المستخدم","name=input('اسمك: ')"),
        Item("الدوال المدمجة","len()","الطول","حساب عدد العناصر أو الأحرف","len([1,2,3])"),
        Item("الدوال المدمجة","type()","نوع البيانات","معرفة نوع قيمة","type(10)"),
        Item("الدوال المدمجة","id()","معرّف الكائن","الحصول على هوية الكائن أثناء التشغيل","id(obj)"),
        Item("الدوال المدمجة","repr()","تمثيل الكائن","الحصول على تمثيل نصي مناسب للمبرمج","repr('hi')"),
        Item("الدوال المدمجة","str()","تحويل إلى نص","تحويل قيمة إلى نص","str(123)"),
        Item("الدوال المدمجة","int()","عدد صحيح","تحويل قيمة إلى integer","int('42')"),
        Item("الدوال المدمجة","float()","عدد عشري","تحويل قيمة إلى float","float('3.14')"),
        Item("الدوال المدمجة","complex()","عدد مركب","إنشاء عدد مركب","complex(2,3)"),
        Item("الدوال المدمجة","bool()","قيمة منطقية","تحويل قيمة إلى True أو False","bool(1)"),
        Item("الدوال المدمجة","list()","قائمة","إنشاء قائمة من iterable","list('abc')"),
        Item("الدوال المدمجة","tuple()","صف","إنشاء tuple","tuple([1,2])"),
        Item("الدوال المدمجة","set()","مجموعة","إنشاء set وإزالة التكرار","set([1,1,2])"),
        Item("الدوال المدمجة","frozenset()","مجموعة ثابتة","إنشاء مجموعة غير قابلة للتعديل","frozenset([1,2])"),
        Item("الدوال المدمجة","dict()","قاموس","إنشاء قاموس مفاتيح وقيم","dict(name='Ali')"),
        Item("الدوال المدمجة","range()","نطاق أعداد","إنشاء تسلسل كسول من الأعداد","range(5)"),
        Item("الدوال المدمجة","sum()","المجموع","جمع عناصر رقمية","sum([1,2,3])"),
        Item("الدوال المدمجة","max()","الأكبر","إيجاد أكبر قيمة","max([2,8,3])"),
        Item("الدوال المدمجة","min()","الأصغر","إيجاد أصغر قيمة","min([2,8,3])"),
        Item("الدوال المدمجة","abs()","القيمة المطلقة","إزالة الإشارة السالبة","abs(-9)"),
        Item("الدوال المدمجة","round()","التقريب","تقريب الأرقام","round(3.14159,2)"),
        Item("الدوال المدمجة","pow()","الأس","حساب القوة","pow(2,3)"),
        Item("الدوال المدمجة","divmod()","القسمة والباقي","إرجاع خارج القسمة والباقي","divmod(10,3)"),
        Item("الدوال المدمجة","bin()","ثنائي","تحويل العدد إلى تمثيل ثنائي","bin(10)"),
        Item("الدوال المدمجة","oct()","ثماني","تحويل العدد إلى تمثيل ثماني","oct(10)"),
        Item("الدوال المدمجة","hex()","سداسي عشري","تحويل العدد إلى تمثيل hex","hex(255)"),
        Item("الدوال المدمجة","ord()","رقم الحرف","تحويل حرف إلى Unicode code point","ord('A')"),
        Item("الدوال المدمجة","chr()","حرف من رقم","تحويل code point إلى حرف","chr(65)"),
        Item("الدوال المدمجة","ascii()","تمثيل ASCII","إرجاع تمثيل قابل للطباعة","ascii('ع')"),
        Item("الدوال المدمجة","format()","تنسيق","تنسيق قيمة بنمط محدد","format(3.14,'.1f')"),
        Item("الدوال المدمجة","eval()","تقييم تعبير","تقييم تعبير Python؛ استخدم بحذر","eval('2+3')"),
        Item("الدوال المدمجة","exec()","تنفيذ كود","تنفيذ كود Python ديناميكي؛ استخدم بحذر","exec('x=2')"),
        Item("الدوال المدمجة","compile()","ترجمة كود","تحويل المصدر إلى code object","compile('2+2','','eval')"),
        Item("الدوال المدمجة","globals()","النطاق العام","الوصول إلى namespace العام","globals()"),
        Item("الدوال المدمجة","locals()","النطاق المحلي","الوصول إلى namespace المحلي","locals()"),
        Item("الدوال المدمجة","vars()","خصائص الكائن","الحصول على __dict__ عند توفره","vars(obj)"),
        Item("الدوال المدمجة","dir()","الأعضاء","عرض أسماء الخصائص والدوال","dir(str)"),
        Item("الدوال المدمجة","help()","المساعدة","عرض المساعدة التوثيقية","help(str)"),
        Item("الدوال المدمجة","hash()","تجزئة","الحصول على hash للكائن القابل للتجزئة","hash('abc')"),
        Item("الدوال المدمجة","isinstance()","فحص النوع","التحقق من نوع الكائن","isinstance(5,int)"),
        Item("الدوال المدمجة","issubclass()","فحص الفئة","التحقق من علاقة الوراثة","issubclass(bool,int)"),
        Item("الدوال المدمجة","callable()","قابل للاستدعاء","معرفة هل الكائن يمكن استدعاؤه","callable(print)"),
        Item("الدوال المدمجة","all()","كلها صحيحة","True إذا كانت كل العناصر truthy","all([1,True])"),
        Item("الدوال المدمجة","any()","أي عنصر صحيح","True إذا وجد عنصر truthy","any([0,1])"),
        Item("الدوال المدمجة","enumerate()","ترقيم","إرجاع index مع العنصر","list(enumerate(['a','b']))"),
        Item("الدوال المدمجة","zip()","دمج متوازٍ","تجميع عدة iterables معًا","list(zip([1,2],['a','b']))"),
        Item("الدوال المدمجة","map()","تطبيق دالة","تطبيق دالة على عناصر iterable","list(map(str,[1,2]))"),
        Item("الدوال المدمجة","filter()","تصفية","اختيار العناصر التي تحقق شرطًا","list(filter(bool,[0,1,2]))"),
        Item("الدوال المدمجة","sorted()","ترتيب","إرجاع iterable مرتبًا","sorted([3,1,2])"),
        Item("الدوال المدمجة","reversed()","عكس الترتيب","إرجاع iterator عكسي","list(reversed([1,2,3]))"),
        Item("الدوال المدمجة","iter()","مكرّر","الحصول على iterator","it=iter([1,2])"),
        Item("الدوال المدمجة","next()","العنصر التالي","الحصول على العنصر التالي من iterator","next(iter([1,2]))"),
        Item("الدوال المدمجة","open()","فتح ملف","فتح ملف للقراءة أو الكتابة","open('data.txt','r')"),
        Item("الدوال المدمجة","property()","خاصية","إنشاء property داخل class","property(getter)"),
        Item("الدوال المدمجة","staticmethod()","دالة ثابتة","تحويل method إلى static method","staticmethod(fn)"),
        Item("الدوال المدمجة","classmethod()","دالة فئة","تحويل method إلى class method","classmethod(fn)"),
        Item("الدوال المدمجة","super()","الأب","الوصول إلى class الأب","super().__init__()"),
        Item("الكلمات المحجوزة","if","إذا","تنفيذ كتلة عند تحقق شرط","if x > 0: pass"),
        Item("الكلمات المحجوزة","elif","وإلا إذا","اختبار شرط بديل","elif x == 0: pass"),
        Item("الكلمات المحجوزة","else","وإلا","تنفيذ البديل","else: pass"),
        Item("الكلمات المحجوزة","for","حلقة for","تكرار على iterable","for x in items: pass"),
        Item("الكلمات المحجوزة","while","حلقة while","التكرار ما دام الشرط صحيحًا","while x < 5: x += 1"),
        Item("الكلمات المحجوزة","break","إيقاف الحلقة","الخروج من أقرب حلقة","for x in xs: break"),
        Item("الكلمات المحجوزة","continue","تخطي دورة","الانتقال للدورة التالية","for x in xs: continue"),
        Item("الكلمات المحجوزة","pass","لا شيء","عنصر نائب لكتلة فارغة","def f(): pass"),
        Item("الكلمات المحجوزة","def","تعريف دالة","إنشاء دالة","def add(a,b): return a+b"),
        Item("الكلمات المحجوزة","return","إرجاع","إرجاع قيمة من الدالة","return result"),
        Item("الكلمات المحجوزة","yield","إنتاج قيمة","إنشاء generator وإرجاع القيم تدريجيًا","yield value"),
        Item("الكلمات المحجوزة","class","فئة","تعريف class","class Person: pass"),
        Item("الكلمات المحجوزة","import","استيراد","استيراد module","import math"),
        Item("الكلمات المحجوزة","from","استيراد من","استيراد اسم من module","from math import sqrt"),
        Item("الكلمات المحجوزة","as","اسم مستعار","إعطاء alias","import numpy as np"),
        Item("الكلمات المحجوزة","try","محاولة","بدء معالجة استثناء","try: risky()"),
        Item("الكلمات المحجوزة","except","استثناء","التقاط exception","except ValueError: pass"),
        Item("الكلمات المحجوزة","finally","دائمًا","تنفيذ بعد try/except","finally: close()"),
        Item("الكلمات المحجوزة","raise","رفع استثناء","إطلاق exception يدويًا","raise ValueError('خطأ')"),
        Item("الكلمات المحجوزة","assert","تأكيد","اختبار شرط أثناء التطوير","assert x > 0"),
        Item("الكلمات المحجوزة","with","سياق","إدارة موارد تلقائيًا","with open('x') as f: pass"),
        Item("الكلمات المحجوزة","lambda","دالة مجهولة","إنشاء دالة قصيرة","lambda x: x*2"),
        Item("الكلمات المحجوزة","and","و منطقي","ربط شرطين","x>0 and y>0"),
        Item("الكلمات المحجوزة","or","أو منطقي","بديل بين شرطين","x==1 or x==2"),
        Item("الكلمات المحجوزة","not","نفي","عكس القيمة المنطقية","not ready"),
        Item("الكلمات المحجوزة","in","ضمن","التحقق من العضوية","'a' in text"),
        Item("الكلمات المحجوزة","is","هوية","مقارنة هوية كائنين","a is None"),
        Item("الكلمات المحجوزة","True","صحيح","قيمة منطقية صحيحة","ok=True"),
        Item("الكلمات المحجوزة","False","خطأ","قيمة منطقية خاطئة","ok=False"),
        Item("الكلمات المحجوزة","None","لا قيمة","تمثيل غياب القيمة","result=None"),
        Item("الكلمات المحجوزة","global","متغير عام","تعديل اسم global داخل دالة","global counter"),
        Item("الكلمات المحجوزة","nonlocal","متغير خارجي محلي","تعديل اسم من enclosing scope","nonlocal count"),
        Item("الكلمات المحجوزة","del","حذف","حذف اسم أو عنصر","del items[0]"),
        Item("الأنواع","list","قائمة","تخزين عناصر قابلة للتعديل","items=[1,2,3]"),
        Item("الأنواع","tuple","صف","تخزين عناصر ثابتة نسبيًا","point=(10,20)"),
        Item("الأنواع","dict","قاموس","مفتاح وقيمة","user={'name':'Ali'}"),
        Item("الأنواع","set","مجموعة","عناصر فريدة غير مرتبة","tags={'python','code'}"),
        Item("الأنواع","str","نص","تخزين النصوص","name='Ali'"),
        Item("الأنواع","int","عدد صحيح","أعداد بدون كسور","age=20"),
        Item("الأنواع","float","عدد عشري","أعداد ذات كسور","price=3.5"),
        Item("الأنواع","bool","منطقي","True/False","active=True"),
        Item("الأنواع","bytes","بايتات","بيانات ثنائية غير قابلة للتعديل","data=b'abc'"),
        Item("الأنواع","bytearray","مصفوفة بايتات","بيانات ثنائية قابلة للتعديل","data=bytearray(b'abc')"),
        Item("المفاهيم","f-string","سلسلة منسقة","إدخال المتغيرات داخل النص","name='Ali'; print(f'Hi {name}')"),
        Item("المفاهيم","list comprehension","اختصار إنشاء قائمة","إنشاء قائمة بتعبير وحلقة","[x*x for x in range(5)]"),
        Item("المفاهيم","dict comprehension","اختصار إنشاء قاموس","إنشاء قاموس بتعبير","{x:x*x for x in range(5)}"),
        Item("المفاهيم","generator expression","توليد كسول","توفير الذاكرة مع بيانات كبيرة","(x*x for x in range(10))"),
        Item("المفاهيم","slice","تقطيع","أخذ جزء من sequence","items[1:4]"),
        Item("المفاهيم","unpacking","فك التجميع","توزيع عناصر iterable على متغيرات","a,b=[1,2]"),
        Item("المفاهيم","*args","وسائط متعددة","استقبال عدد غير محدد من positional args","def f(*args): pass"),
        Item("المفاهيم","**kwargs","وسائط مسماة","استقبال عدد غير محدد من keyword args","def f(**kwargs): pass"),
        Item("المفاهيم","docstring","توثيق الدالة","شرح الدالة داخلها","def f(): '''شرح'''"),
        Item("المكتبة القياسية","math","رياضيات","دوال وثوابت رياضية","import math; math.sqrt(9)"),
        Item("المكتبة القياسية","random","عشوائية","توليد قيم عشوائية","import random; random.randint(1,10)"),
        Item("المكتبة القياسية","datetime","تاريخ ووقت","التعامل مع التواريخ والأوقات","from datetime import datetime"),
        Item("المكتبة القياسية","os","نظام التشغيل","التعامل مع الملفات والمسارات والبيئة","import os; os.getcwd()"),
        Item("المكتبة القياسية","pathlib","مسارات حديثة","التعامل مع مسارات الملفات بالكائنات","from pathlib import Path"),
        Item("المكتبة القياسية","sys","بيئة Python","الوصول لإعدادات ومعلومات المفسر","import sys; sys.version"),
        Item("المكتبة القياسية","json","JSON","ترميز وفك ترميز JSON","import json; json.dumps({'a':1})"),
        Item("المكتبة القياسية","re","التعابير النمطية","البحث والمطابقة بالنمط","import re; re.findall(r'\\d+','a12')"),
        Item("المكتبة القياسية","collections","هياكل بيانات","أدوات مثل Counter وdeque","from collections import Counter"),
        Item("المكتبة القياسية","itertools","تكرار متقدم","أدوات iterator فعالة","import itertools"),
        Item("المكتبة القياسية","functools","أدوات الدوال","تقنيات مثل lru_cache وpartial","from functools import lru_cache"),
        Item("المكتبة القياسية","statistics","إحصاء","المتوسط والوسيط وغيرها","import statistics; statistics.mean([1,2,3])"),
        Item("المكتبة القياسية","time","الوقت","التأخير وقياس الزمن","import time; time.sleep(1)"),
        Item("المكتبة القياسية","subprocess","عمليات خارجية","تشغيل برامج وعمليات نظام","import subprocess"),
        Item("المكتبة القياسية","sqlite3","قاعدة SQLite","التعامل مع قاعدة بيانات محلية","import sqlite3"),
        Item("المكتبة القياسية","csv","ملفات CSV","قراءة وكتابة CSV","import csv"),
        Item("المكتبة القياسية","typing","تلميحات الأنواع","كتابة type hints","from typing import List"),
        Item("المكتبة القياسية","dataclasses","فئات بيانات","إنشاء classes للبيانات بسهولة","from dataclasses import dataclass"),
        Item("المكتبة القياسية","argparse","وسائط سطر الأوامر","بناء CLI احترافي","import argparse"),
        Item("المكتبة القياسية","logging","السجلات","تسجيل أحداث البرنامج","import logging; logging.info('ok')"),
        Item("المكتبة القياسية","unittest","اختبارات","كتابة اختبارات وحدة","import unittest"),
        Item("المكتبة القياسية","pprint","طباعة منظمة","عرض هياكل البيانات بشكل مقروء","from pprint import pprint"),
        Item("طرق شائعة","append()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.append(...)"),
        Item("طرق شائعة","extend()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.extend(...)"),
        Item("طرق شائعة","insert()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.insert(...)"),
        Item("طرق شائعة","remove()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.remove(...)"),
        Item("طرق شائعة","pop()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.pop(...)"),
        Item("طرق شائعة","clear()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.clear(...)"),
        Item("طرق شائعة","index()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.index(...)"),
        Item("طرق شائعة","count()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.count(...)"),
        Item("طرق شائعة","sort()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.sort(...)"),
        Item("طرق شائعة","reverse()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.reverse(...)"),
        Item("طرق شائعة","keys()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.keys(...)"),
        Item("طرق شائعة","values()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.values(...)"),
        Item("طرق شائعة","items()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.items(...)"),
        Item("طرق شائعة","get()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.get(...)"),
        Item("طرق شائعة","setdefault()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.setdefault(...)"),
        Item("طرق شائعة","update()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.update(...)"),
        Item("طرق شائعة","popitem()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.popitem(...)"),
        Item("طرق شائعة","upper()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.upper(...)"),
        Item("طرق شائعة","lower()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.lower(...)"),
        Item("طرق شائعة","strip()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.strip(...)"),
        Item("طرق شائعة","split()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.split(...)"),
        Item("طرق شائعة","join()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.join(...)"),
        Item("طرق شائعة","replace()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.replace(...)"),
        Item("طرق شائعة","find()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.find(...)"),
        Item("طرق شائعة","startswith()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.startswith(...)"),
        Item("طرق شائعة","endswith()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.endswith(...)"),
        Item("طرق شائعة","format()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.format(...)"),
        Item("طرق شائعة","encode()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.encode(...)"),
        Item("طرق شائعة","decode()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.decode(...)"),
        Item("طرق شائعة","startswith()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.startswith(...)"),
        Item("طرق شائعة","endswith()","دالة/طريقة شائعة في Python","تسهيل التعامل مع النصوص أو القوائم أو القواميس حسب النوع","result = obj.endswith(...)")
    )
    private val prefs by lazy { getSharedPreferences("prefs", MODE_PRIVATE) }
    private var favorites = mutableSetOf<String>()
    private var dark = false
    private var showFavorites = false
    private var current = items
    private var english = false

    

    private val prefs by lazy { getSharedPreferences("learning", MODE_PRIVATE) }
    private var favorites=mutableSetOf<String>()
    private var learned=mutableSetOf<String>()
    private var hard=mutableSetOf<String>()
    private var english=false
    private var dark=false
    private var showingFavorites=false

    override fun onCreate(state:Bundle?) {
        super.onCreate(state)
        setContentView(R.layout.activity_main)

        favorites=prefs.getStringSet("favorites",emptySet())!!.toMutableSet()
        learned=prefs.getStringSet("learned",emptySet())!!.toMutableSet()
        hard=prefs.getStringSet("hard",emptySet())!!.toMutableSet()

        val title=findViewById<TextView>(R.id.title)
        val subtitle=findViewById<TextView>(R.id.subtitle)
        val search=findViewById<EditText>(R.id.search)
        val spinner=findViewById<Spinner>(R.id.category)
        val list=findViewById<ListView>(R.id.list)
        val lang=findViewById<Button>(R.id.lang)
        val theme=findViewById<Button>(R.id.theme)
        val all=findViewById<Button>(R.id.allBtn)
        val fav=findViewById<Button>(R.id.favBtn)
        val learn=findViewById<Button>(R.id.learnBtn)
        val test=findViewById<Button>(R.id.testBtn)
        val progress=findViewById<TextView>(R.id.progress)

        val cats=listOf("الكل")+items.map{it.category}.distinct()
        spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,cats)

        fun refresh() {
            val q=search.text.toString()
            val cat=spinner.selectedItem?.toString()?:"الكل"
            val filtered=items.filter {
                (cat=="الكل"||it.category==cat) &&
                (!showingFavorites||favorites.contains(it.name)) &&
                (q.isBlank()||it.name.contains(q,true)||it.meaning.contains(q,true)||it.benefit.contains(q,true))
            }
            val learnedCount=learned.size.coerceAtMost(items.size)
            progress.text=if(english)"Progress: ${learnedCount*100/items.size}% (${learnedCount}/${items.size})"
                         else "📈 نسبة الحفظ: ${learnedCount*100/items.size}% (${learnedCount}/${items.size})"
            list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,
                filtered.map{(if(learned.contains(it.name))"✅ " else if(hard.contains(it.name))"🔴 " else "🟦 ")+it.name+" — "+it.meaning})
            list.setOnItemClickListener{_,_,pos,_->showCard(filtered[pos],refresh)}
        }
        refresh()

        search.addTextChangedListener(object:TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){}
            override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){refresh()}
            override fun afterTextChanged(e:Editable?){}
        })
        spinner.onItemSelectedListener=object:AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(p:AdapterView<*>?){}
            override fun onItemSelected(p:AdapterView<*>?,v:android.view.View?,pos:Int,id:Long){refresh()}
        }

        all.setOnClickListener{showingFavorites=false;refresh()}
        fav.setOnClickListener{showingFavorites=true;refresh()}
        learn.setOnClickListener{startFlashcards(refresh)}
        test.setOnClickListener{quiz()}
        theme.setOnClickListener{dark=!dark;theme.text=if(dark)"☀️" else "🌙";applyTheme()}
        lang.setOnClickListener{
            english=!english
            lang.text=if(english)"AR" else "EN"
            title.text=if(english)"Python Encyclopedia" else "موسوعة Python"
            subtitle.text=if(english)"Learn and memorize Python more easily" else "تعلّم Python واحفظها بطريقة أسهل"
            search.hint=if(english)"🔎 Search for a function or keyword..." else "🔎 ابحث عن دالة أو كلمة..."
            all.text=if(english)"📚 All" else "📚 الكل"
            fav.text=if(english)"⭐ Favorites" else "⭐ المفضلة"
            learn.text=if(english)"🃏 Flashcards" else "🃏 الحفظ"
            test.text=if(english)"🧠 Quick Quiz" else "🧠 اختبار سريع"
            refresh()
        }
    }

    private fun save() {
        prefs.edit().putStringSet("favorites",favorites).putStringSet("learned",learned).putStringSet("hard",hard).apply()
    }

    private fun showCard(x:Item,refresh:()->Unit) {
        val message=if(english)
            "${x.name}\n\nMeaning: ${x.meaning}\n\nWhy use it? ${x.benefit}\n\nExample:\n${x.example}"
        else
            "${x.name}\n\nالمعنى: ${x.meaning}\n\nالفائدة: ${x.benefit}\n\nمثال:\n${x.example}"
        AlertDialog.Builder(this).setTitle(if(english)"Flashcard" else "🃏 بطاقة التعلم")
            .setMessage(message)
            .setNeutralButton(if(favorites.contains(x.name))"☆" else "⭐"){
                favorites.remove(x.name).also{ if(!favorites.contains(x.name)) favorites.add(x.name) }
                save();refresh()
            }
            .setPositiveButton(if(english)"I know it ✅" else "حفظتها ✅"){_,_->learned.add(x.name);hard.remove(x.name);save();refresh()}
            .setNegativeButton(if(english)"Need review 🔴" else "أحتاج مراجعة 🔴"){_,_->hard.add(x.name);learned.remove(x.name);save();refresh()}
            .show()
    }

    private fun startFlashcards(refresh:()->Unit) {
        val pool=(items.filter{hard.contains(it.name)}+items.filter{!learned.contains(it.name)&&!hard.contains(it.name)}).distinctBy{it.name}.take(20)
        if(pool.isEmpty()) {
            Toast.makeText(this,if(english)"Great! You have learned everything." else "🎉 ممتاز! لقد حفظت كل العناصر.",Toast.LENGTH_LONG).show()
            return
        }
        var index=0
        fun next() {
            if(index>=pool.size) {
                Toast.makeText(this,if(english)"Review finished!" else "انتهت جلسة المراجعة!",Toast.LENGTH_LONG).show()
                refresh();return
            }
            val x=pool[index++]
            AlertDialog.Builder(this).setTitle("🃏 ${x.name}")
                .setMessage(if(english)"Tap OK to reveal the meaning." else "حاول تذكر المعنى، ثم اضغط «إظهار».")
                .setPositiveButton(if(english)"Show" else "إظهار"){_,_->
                    AlertDialog.Builder(this).setTitle(x.name)
                        .setMessage(if(english)"Meaning: ${x.meaning}\n\nBenefit: ${x.benefit}\n\nExample:\n${x.example}"
                                    else "المعنى: ${x.meaning}\n\nالفائدة: ${x.benefit}\n\nمثال:\n${x.example}")
                        .setPositiveButton(if(english)"Know it ✅" else "حفظتها ✅"){_,_->learned.add(x.name);hard.remove(x.name);save();next()}
                        .setNegativeButton(if(english)"Review again 🔴" else "راجعها 🔴"){_,_->hard.add(x.name);learned.remove(x.name);save();next()}
                        .show()
                }.show()
        }
        next()
    }

    private fun quiz() {
        val q=items.shuffled().take(1).first()
        val choices=(items.filter{it.name!=q.name}.shuffled().take(3).map{it.name}+q.name).shuffled()
        AlertDialog.Builder(this).setTitle(if(english)"🧠 Quiz" else "🧠 اختبار Python")
            .setMessage(if(english)"Which item means: ${q.meaning}?" else "ما العنصر الذي يعني: ${q.meaning}؟")
            .setSingleChoiceItems(choices.toTypedArray(),-1){d,which->
                val ok=choices[which]==q.name
                d.dismiss()
                Toast.makeText(this,if(ok)"✅ "+if(english)"Correct!" else "إجابة صحيحة!" else "❌ "+if(english)"Correct answer: " else "الإجابة الصحيحة: "+q.name,Toast.LENGTH_LONG).show()
            }.show()
    }

    private fun applyTheme() {
        window.decorView.setBackgroundColor(if(dark)Color.rgb(20,25,32)Color.rgb(244,247,251))
        findViewById<TextView>(R.id.title).setTextColor(if(dark)Color.WHITE Color.rgb(22,58,95))
        findViewById<TextView>(R.id.subtitle).setTextColor(if(dark)Color.LTGRAY Color.rgb(85,112,138))
    }
}
